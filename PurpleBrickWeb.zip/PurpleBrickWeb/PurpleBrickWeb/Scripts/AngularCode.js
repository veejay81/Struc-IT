﻿var app = angular.module("myApp", []);
app.controller("myCtrl", function ($scope, $http) {
    debugger;
    $scope.InsertData = function () {
        var Action = document.getElementById("btnSave").getAttribute("value");
        if (Action == "Submit") {
            $scope.Customer = {};
            $scope.Customer.CustomerName = $scope.CusName;
            $scope.Customer.PhoneNumber = $scope.CusPhone;
            $scope.Customer.DOB = $scope.CusDOB;
            $scope.Customer.SEX = $scope.CusSex;
            $scope.Customer.Address = $scope.CusAddress;
            $http({
                method: "post",
                url: "/Purple/Insert_Customer",
                datatype: "json",
                data: JSON.stringify($scope.Customer)
            }).then(function (response) {
                alert(response.data);
                $scope.GetAllData();
                $scope.EmpName = "";
                $scope.EmpCity = "";
                $scope.EmpAge = "";
            })
        } else {
            $scope.Customer = {};
            $scope.Customer.CustomerName = $scope.CusName;
            $scope.Customer.PhoneNumber = $scope.CusPhone;
            $scope.Customer.DOB = $scope.CusDOB;
            $scope.Customer.SEX = $scope.CusSex;
            $scope.Customer.Address = $scope.CusAddress;
            $scope.Employe.ID = document.getElementById("ID_").value;
            $http({
                method: "post",
                url: "/Purple/Update_Employee",
                datatype: "json",
                data: JSON.stringify($scope.Customer)
            }).then(function (response) {
                alert(response.data);
                $scope.GetAllData();
                $scope.CusName = "";
                $scope.CusPhone = "";
                $scope.CusDOB = "";
                $scope.CusSex = "";
                $scope.CusAddress = "";
                document.getElementById("btnSave").setAttribute("value", "Submit");
                document.getElementById("btnSave").style.backgroundColor = "cornflowerblue";
                document.getElementById("spn").innerHTML = "Add New Employee";
            })
        }
    }
    $scope.state = function () {
        $scope.BoardMaster = {};
        $scope.BoardMaster.State = $scope.State;
        $scope.BoardMaster.Size = $scope.Size;
        alert($scope.BoardMaster.State);
        debugger;
        $http({
            method: "post",
            url: "/Purple/GetBoard_cost",
            datatype: "json",
            data: JSON.stringify($scope.BoardMaster)
        }).then(function (response) {
            alert(response.data);
        })
        //$http.get('/Home/Get_state?countryid=' + $scope.CountryId).then(function (d) {

        //    $scope.statelist = d.data;

        //});

    };
    $scope.GetAllData = function () {
        debugger;
        $http({
            method: "get",
            url: "/Purple/Get_AllCustomers"
        }).then(function (response) {
            $scope.Customer = response.data;
        }, function () {
            alert("Error Occur");
        })
    };
    $scope.GetBoardDetails = function () {
        debugger;
        $http({
            method: "get",
            url: "/Purple/Get_BoardDetails"
        }).then(function (response) {
            $scope.BoardDetails = response.data;
        }, function () {
            alert("Error Occur");
        })
    };
    $scope.DeleteEmp = function (Emp) {
        $http({
            method: "post",
            url: "/Purple/Delete_Employee",
            datatype: "json",
            data: JSON.stringify(Emp)
        }).then(function (response) {
            alert(response.data);
            $scope.GetAllData();
        })
    };
    $scope.UpdateEmp = function (Cus) {
        document.getElementById("ID_").value = Cus.ID;
        $scope.CusName = Cus.CustomerName;
        $scope.CusPhone = Cus.PhoneNumber;
        $scope.CusDOB = Cus.DOB;
        $scope.CusSex = Cus.SEX;
        $scope.CusAddress = Cus.Address;

        document.getElementById("btnSave").setAttribute("value", "Update");
        document.getElementById("btnSave").style.backgroundColor = "Yellow";
        document.getElementById("spn").innerHTML = "Update Employee Information";
    }
})