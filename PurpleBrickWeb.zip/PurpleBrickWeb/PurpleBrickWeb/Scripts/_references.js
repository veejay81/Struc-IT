﻿/// <autosync enabled="true" />
/// <reference path="angular.min.js" />
/// <reference path="angularcode.js" />
/// <reference path="angular-mocks.js" />
/// <reference path="bootstrap.js" />
/// <reference path="jquery.validate.js" />
/// <reference path="jquery.validate.unobtrusive.js" />
/// <reference path="respond.js" />
