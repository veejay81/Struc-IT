﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using PurpleBrickWeb.Models;
using System.Net.Http;
using System.Data.Entity.Core.Objects;

namespace PurpleBrickWeb.Controllers
{
    public class PurpleController : Controller
    {
        // GET: Purple
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult Get_AllCustomers()
        {
            using (PurpleBrickEntities Obj = new PurpleBrickEntities())
            {
                List<Customer> Cus = Obj.Customers.ToList();
                return Json(Cus, JsonRequestBehavior.AllowGet);
            }
        }
        
        public int?  GetBoard_cost(BoardMaster BoardMaster)
        {
            using (PurpleBrickEntities Obj = new PurpleBrickEntities())
            {
                List<BoardMaster> Obj1 = Obj.BoardMasters.ToList();
                var price = from st in Obj1
                            where st.Size.Contains(BoardMaster.Size) && st.State.Contains(BoardMaster.State.ToLower())
                            select st.Price;
                int?  myPrice = price.FirstOrDefault();

                return myPrice;
            }
        }

        

        /// <summary>  
        /// Insert New Employee  
        /// </summary>  
        /// <param name="Employe"></param>  
        /// <returns></returns>  
        public string Insert_Customer(Customer Customer)
        {
            if (Customer != null)
            {
                using (PurpleBrickEntities Obj = new PurpleBrickEntities())
                {
                    Obj.Customers.Add(Customer);
                    Obj.SaveChanges();
                    return "Customer Added Successfully";
                }
            }
            else
            {
                return "Customer Not Inserted! Try Again";
            }
        }

    }
}